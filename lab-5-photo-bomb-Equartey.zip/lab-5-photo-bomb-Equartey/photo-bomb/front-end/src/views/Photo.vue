<template>
  <div class="photo" v-if="photo">
    <img class="image" :src="photo.path" />
    <div class="photoInfo">
      <p class="photoTitle">{{ photo.title }}</p>
      <p class="photoName">
        {{ photo.user.firstName }} {{ photo.user.lastName }}
      </p>
    </div>
    <p class="photoDate">{{ formatDate(photo.created) }}</p>

    <div class="comments">
      <div v-for="cmt in comments" v-bind:key="cmt.id">
        <div class="comment">
          <p>{{ cmt.comment }}</p>
          <label>
            {{ cmt.user.firstName }} {{ cmt.user.lastName }} -
            {{ formatDate(cmt.created) }}</label
          >
        </div>
      </div>
    </div>

    <div v-if="user">
      <button @click="setCommenting" class="pure-button button-xsmall">
        <i class="fas fa-plus" />
      </button>
    </div>
    <form class="pure-form" v-if="commenting" @submit.prevent="addComment">
      <legend>Insipire us</legend>
      <fieldset>
        <textarea v-model="comment"></textarea>
        <br />
        <button @click="cancelCommenting" class="pure-button space-right">
          Cancel
        </button>
        <button class="pure-button pure-button-primary" type="submit">
          Submit
        </button>
      </fieldset>
    </form>
  </div>
</template>

<script>
import axios from "axios";
import moment from "moment";

export default {
  name: "photo",
  data() {
    return {
      commenting: false,
      comment: "",
      comments: [],
      photo: null
    };
  },
  async created() {
    this.getComments();
    try {
      console.log(this.$route.params.id);
      let response = await axios.get("/api/photos/" + this.$route.params.id);
      this.photo = { ...response.data };
    } catch (error) {
      this.photo = null;
    }

    try {
      let response = await axios.get("/api/users");
      this.$root.$data.user = response.data.user;
    } catch (error) {
      this.$root.$data.user = null;
    }
  },
  methods: {
    formatDate(date) {
      if (moment(date).diff(Date.now(), "days") < 15)
        return moment(date).fromNow();
      else return moment(date).format("d MMMM YYYY");
    },
    setCommenting() {
      this.commenting = true;
    },
    cancelCommenting() {
      this.commenting = false;
    },
    async addComment() {
      console.log("YEEET");
      try {
        await axios.post("/api/comments/" + this.$route.params.id, {
          comment: this.comment
        });
        this.comment = "";
        this.commenting = false;
        this.getComments();
        return true;
      } catch (error) {
        console.log(error);
      }
    },
    async getComments() {
      try {
        let response = await axios.get(
          "/api/comments/" + this.$route.params.id
        );
        console.log(response.data);
        this.comments = response.data;
        return true;
      } catch (error) {
        console.log(error);
      }
    }
  },
  computed: {
    user() {
      return this.$root.$data.user;
    }
  }
};
</script>

<style scoped>
.photo {
  margin: 0 auto;
}
.photoInfo {
  display: flex;
  justify-content: space-between;
  font-size: 0.8em;
}

.photoInfo p {
  margin: 0px;
}

.photoDate {
  font-size: 0.7em;
  font-weight: normal;
}

p {
  margin: 0px;
}

/* Masonry */
*,
*:before,
*:after {
  box-sizing: inherit;
}

.image-gallery {
  column-gap: 1em;
}

.image {
  margin: 0 0 1.5em;
  display: inline-block;
  width: 100%;
}

.image img {
  width: 100%;
}

/* Masonry on large screens */
@media only screen and (min-width: 1024px) {
  .image-gallery {
    column-count: 4;
  }
}

/* Masonry on medium-sized screens */
@media only screen and (max-width: 1023px) and (min-width: 768px) {
  .image-gallery {
    column-count: 3;
  }
}

/* Masonry on small screens */
@media only screen and (max-width: 767px) and (min-width: 540px) {
  .image-gallery {
    column-count: 2;
  }
}

.comments {
  margin: 30px 0;
  padding-top: 30px;
  border-top: 1px solid #333;
}

.comment {
  margin: 10px 0;
}

.comment label {
  font-size: 14px;
  color: #888;
}

.pure-button {
  margin-bottom: 40px;
}
</style>
