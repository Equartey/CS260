# Lab 5 Tutorials

Introductory tutorials:

* [Part 1](/tutorials/part1.md): Vue Setup
* [Part 2](/tutorials/part2.md): Navigation
* [Part 3](/tutorials/part3.md): Server Setup
* [Part 4](/tutorials/part4.md): Authentication
* [Part 5](/tutorials/part5.md): Uploading Photos
* [Part 6](/tutorials/part6.md): Home Page

Additional functionality:

* [Part 7](/tutorials/part7.md): Photo Page
* [Part 8](/tutorials/part8.md): Comments

Installation:

* [Part 9](/tutorials/part9.md): Digital Ocean
